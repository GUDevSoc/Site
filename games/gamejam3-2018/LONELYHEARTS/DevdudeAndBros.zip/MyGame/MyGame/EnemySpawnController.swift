//
//  EnemySpawnController.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class EnemySpawnController {
  
  var timer: Int = 0
  var timerInterval: Int = 140
  var enemiesSpawned: Int = 0
  
  var scene: SKScene
  
  init(scene: SKScene) {
    self.scene = scene
  }
  
  func update(_ currentTime: TimeInterval) {
    timer += 1
    
    if timerInterval == timer {
      spawnEnemy()
      timer = 0
    }
  }
  
  func spawnEnemy() {
    let spawnLocation: CGPoint
    let spawnDirectionNumber = rand(min: 0, max: 2)
    
    let backgroundNode = scene.childNode(withName: "background") as! SKSpriteNode
    
    if spawnDirectionNumber == 0 { // from right
      spawnLocation = CGPoint(x: backgroundNode.position.x+0.5*backgroundNode.size.width, y: backgroundNode.position.y+CGFloat(rand(min: Int(-0.5*backgroundNode.size.height), max: Int(0.5*backgroundNode.size.height))))
    } else if spawnDirectionNumber == 1 { // from up
      spawnLocation = CGPoint(x: backgroundNode.position.x+CGFloat(rand(min: 0, max: Int(0.5*backgroundNode.size.width))), y: backgroundNode.position.y+0.5*backgroundNode.size.height)
    } else { // from down
      spawnLocation = CGPoint(x: backgroundNode.position.x+CGFloat(rand(min: 0, max: Int(0.5*backgroundNode.size.width))), y: backgroundNode.position.y-0.5*backgroundNode.size.height)
    }
    
    var targetLocation: CGPoint
    
    let gameScene = scene as! GameScene
    let enemyWillTargetBase = rand(min: 0, max: 1) == 0
    
    if enemyWillTargetBase {
      targetLocation = gameScene.mainBase.node.position
    } else {
      let targetDepot = [gameScene.rubbishDepot, gameScene.goodDepot, gameScene.valuableDepot, gameScene.legendaryDepot][rand(min: 0, max: 3)]!
      targetLocation = targetDepot.node.position
    }
    
    let enemy = Enemy(type: .base, spawnLocation: spawnLocation, targetLocation: targetLocation )
        
    scene.addChild(enemy)
    
    enemiesSpawned += 1
    
    if enemiesSpawned % 5 == 0 {
      if timerInterval > 50 { timerInterval -= 10 }
    }
  }
}
