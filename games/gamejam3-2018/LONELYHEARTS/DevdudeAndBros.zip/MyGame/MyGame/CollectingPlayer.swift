//
//  CollectingPlayer.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class CollectingPlayer: Player {
  
  var salvageCollided: Salvage?
  var salvageCarried: Salvage?
  
  var salvageDepotCollided: SalvageDepot?
  
  let maxHealth = 25
  var health: Int
  
  var hasSpeed: Bool = false
  
  override init(withNode node: SKSpriteNode) {
    health = maxHealth
    
    super.init(withNode: node)
    
    self.node.physicsBody?.categoryBitMask = CategoryMasks.collectingPlayer
    self.node.physicsBody?.contactTestBitMask = CategoryMasks.salvage | CategoryMasks.salvageDepot | CategoryMasks.enemy
    self.node.physicsBody?.collisionBitMask &= ~CategoryMasks.shootingPlayer
    self.node.physicsBody?.collisionBitMask &= ~CategoryMasks.salvageDepot
  }
  
  func collidedWithSalvage(_ salvage: Salvage) {
    salvageCollided = salvage
  }
  
  func uncollidedWithSalvage(_ salvage: Salvage) {
    if salvage === salvageCollided { salvageCollided = nil }
  }
  
  func collidedWithSalvageDepot(_ depot: SalvageDepot) {
    salvageDepotCollided = depot
  }
  
  func uncollidedWithSalvageDepot(_ depot: SalvageDepot) {
    if depot === salvageDepotCollided { salvageDepotCollided = nil }
  }
  
  func spacePressed() {
    if salvageCarried == nil {
      guard let salvage = salvageCollided else { return }
      
      salvageCarried = salvage
      
      salvage.removeFromParent()
      salvage.physicsBody = nil
      salvage.position = CGPoint(x: 0.25*self.node.size.width, y: 0.55*self.node.size.height)
      self.node.addChild(salvage)
      salvage.pickedUp()
      self.node.physicsBody?.velocity = .zero
      
      setSpeedForSalvageType(salvage.type)
      self.node.run(SKAction.playSoundFileNamed("drop_item.wav", waitForCompletion:false))
    } else {
      guard let salvage = salvageCarried else { return }
      
      salvageCarried = nil
      
      if let salvageDepot = salvageDepotCollided {
        if salvageDepot.type == salvage.type {
          salvage.removeFromParent()
          salvageDepot.recieveSalvage()
          salvageCollided = nil
          setSpeedToNormal()
          return
        }
      }
      
      let salvageDepot = (self.node.parent as! GameScene).depotForType(salvage.type)
      
      if node.frame.intersects(salvageDepot.node.frame) {
        salvage.removeFromParent()
        salvageDepot.recieveSalvage()
        salvageCollided = nil
        setSpeedToNormal()
        return
      }
      
      salvage.move(toParent: (self.node.parent as! SKScene))
      salvage.makePhysicsBody()
      salvage.droppedOff()
      
      setSpeedToNormal()
    }
  }
  
  func setSpeedForSalvageType(_ type: SalvageType) {
    switch type {
    case .rubbish:
      speed = 2.75 + (hasSpeed ? 2 : 0)
      maxVelocity = 400 + (hasSpeed ? 200 : 0)
    case .good:
      speed = 2.25 + (hasSpeed ? 2 : 0)
      maxVelocity = 300 + (hasSpeed ? 200 : 0)
    case .valuable:
      speed = 1.6 + (hasSpeed ? 2 : 0)
      maxVelocity = 200 + (hasSpeed ? 200 : 0)
    case .legendary:
      speed = 1 + (hasSpeed ? 2 : 0)
      maxVelocity = 100 + (hasSpeed ? 200 : 0)
    }
  }
  
  func setSpeedToNormal() {
    speed = 3
    maxVelocity = 350
  }
  
  func hitByEnemy() {
    health -= 1
    
    if health == 0 {
      self.node.removeFromParent()
    }
    
    makeHealthBar()
  }
  
  func makeHealthBar() {
    if let healthBar = node.childNode(withName: "healthBar") {
      healthBar.removeFromParent()
    }
    
    let boundingRect = SKShapeNode(rect: CGRect(x: -0.3*node.size.width, y: 0.3*node.size.width, width: 0.6*node.size.width, height: 5))
    boundingRect.strokeColor = .magenta
    boundingRect.name = "healthBar"
    boundingRect.zPosition = 10
    
    let healthBar = SKShapeNode(rect: CGRect(x: -0.3*node.size.width, y: 0.3*node.size.width, width: 0.6*node.size.width*CGFloat(health)/CGFloat(maxHealth), height: 5))
    healthBar.lineWidth = 0
    healthBar.fillColor = .green
    healthBar.zPosition = 9
    
    boundingRect.addChild(healthBar)
    boundingRect.xScale = node.xScale
    
    self.node.addChild(boundingRect)
  }
  
  func pickedUpSpeed() {
    hasSpeed = true
    speed += 2
    maxVelocity += 200
  }
  func speedExpired() {
    hasSpeed = false
    speed -= 2
    maxVelocity -= 200
  }
  
  func pickedUpHeart() {
    health += 5
    if health > maxHealth { health = maxHealth }
    makeHealthBar()
  }
  
}


