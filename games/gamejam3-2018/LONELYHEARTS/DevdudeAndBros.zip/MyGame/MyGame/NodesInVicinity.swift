//
//  NodesInVicinity.swift
//  MyGame
//
//  Created by Youssef Moawad on 25/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

extension SKNode {
  private func squareDistanceTo(_ point: CGPoint) -> CGFloat {
    let dx = point.x - position.x
    let dy = point.y - position.y
    
    return (dx * dx + dy * dy)
  }
  
  func nearestNode(point: CGPoint) -> SKNode {
    return children.min() {
      $0.squareDistanceTo(point) < $1.squareDistanceTo(point)
      } ?? self
  }
  
  func nodesInVicinity(point: CGPoint, tolerance: CGFloat) -> [SKNode] {
    let squareTolerance = tolerance * tolerance
    
    return children.filter() {
      $0.squareDistanceTo(point) <= squareTolerance
    }
  }
}
