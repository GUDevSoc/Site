//
//  GameScene.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
  
  var shootingPlayer: ShootingPlayer!
  var collectingPlayer: CollectingPlayer!
  
  var rubbishDepot: SalvageDepot!
  var goodDepot: SalvageDepot!
  var valuableDepot: SalvageDepot!
  var legendaryDepot: SalvageDepot!
  
  var mainBase: MainBase!
  
  var enemySpawnController: EnemySpawnController!
  
  var score = 0
  var scoreLabel: SKLabelNode!
  
  var backgroundMusic: SKAudioNode!
  
  override func didMove(to view: SKView) {
    shootingPlayer = ShootingPlayer(withNode: (childNode(withName: "shootingPlayer") as! SKSpriteNode))
    collectingPlayer = CollectingPlayer(withNode: (childNode(withName: "collectingPlayer") as! SKSpriteNode))

    rubbishDepot = SalvageDepot(type: .rubbish, node: (childNode(withName: "rubbishDepot") as! SKSpriteNode))
    goodDepot = SalvageDepot(type: .good, node: (childNode(withName: "goodDepot") as! SKSpriteNode))
    valuableDepot = SalvageDepot(type: .valuable, node: (childNode(withName: "valuableDepot") as! SKSpriteNode))
    legendaryDepot = SalvageDepot(type: .legendary, node: (childNode(withName: "legendaryDepot") as! SKSpriteNode))
    
    mainBase = MainBase(node: childNode(withName: "mainBase") as! SKSpriteNode)
    
    scoreLabel = childNode(withName: "scoreLabel") as! SKLabelNode
    
    enemySpawnController = EnemySpawnController(scene: self)

    self.physicsWorld.gravity = .zero
    self.physicsWorld.contactDelegate = self
    
    let background = childNode(withName: "background") as! SKSpriteNode
    background.physicsBody = SKPhysicsBody(edgeLoopFrom: background.frame)
    background.physicsBody?.restitution = 0
    background.physicsBody?.categoryBitMask = CategoryMasks.boundary
    
    if let musicURL = Bundle.main.url(forResource: "bg-music", withExtension: "wav") {
      backgroundMusic = SKAudioNode(url: musicURL)
      addChild(backgroundMusic)
    }
  }  
  
  func touchDown(atPoint pos : CGPoint) {
    shootingPlayer.shoot()
  }
  
  func touchMoved(toPoint pos : CGPoint) {

  }
  
  func touchUp(atPoint pos : CGPoint) {

  }
  
  override func mouseDown(with event: NSEvent) {
    self.touchDown(atPoint: event.location(in: self))
  }
  
  override func mouseDragged(with event: NSEvent) {
    self.touchMoved(toPoint: event.location(in: self))
  }
  
  override func mouseUp(with event: NSEvent) {
    self.touchUp(atPoint: event.location(in: self))
  }
  
  override func mouseMoved(with event: NSEvent) {
    shootingPlayer.mouseMoved(toPosition: event.location(in: self))
    collectingPlayer.mouseMoved(toPosition: event.location(in: self))
  }
  
  override func keyDown(with event: NSEvent) {
    switch event.keyCode {
    case 126: // Up Arrow
      shootingPlayer.startMoving(inDirection: .up)
    case 125: // Down Arrow
      shootingPlayer.startMoving(inDirection: .down)
    case 123: // Left Arrow
      shootingPlayer.startMoving(inDirection: .left)
    case 124: // Right Arrow
      shootingPlayer.startMoving(inDirection: .right)
    case 49: // Space
      break
    case 13: // W
      collectingPlayer.startMoving(inDirection: .up)
    case 1: // S
      collectingPlayer.startMoving(inDirection: .down)
    case 0: // A
      collectingPlayer.startMoving(inDirection: .left)
    case 2: // D
      collectingPlayer.startMoving(inDirection: .right)
    default:
      break
    }
  }
  
  override func keyUp(with event: NSEvent) {
    switch event.keyCode {
    case 126: // Up Arrow
      shootingPlayer.stopMoving(inDirection: .up)
    case 125: // Down Arrow
      shootingPlayer.stopMoving(inDirection: .down)
    case 123: // Left Arrow
      shootingPlayer.stopMoving(inDirection: .left)
    case 124: // Right Arrow
      shootingPlayer.stopMoving(inDirection: .right)
    case 49: // Space
      collectingPlayer.spacePressed()
    case 13: // W
      collectingPlayer.stopMoving(inDirection: .up)
    case 1: // S
      collectingPlayer.stopMoving(inDirection: .down)
    case 0: // A
      collectingPlayer.stopMoving(inDirection: .left)
    case 2: // D
      collectingPlayer.stopMoving(inDirection: .right)
    default:
      break
    }
  }
  
  override func update(_ currentTime: TimeInterval) {
    shootingPlayer.update(currentTime)
    collectingPlayer.update(currentTime)
    enemySpawnController.update(currentTime)
  }
  
  func didBegin(_ contact: SKPhysicsContact) {
    
    // BULLET & BOUNDARY
    if (contact.bodyA.categoryBitMask == CategoryMasks.boundary) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.bullet) {
      
      (contact.bodyB.node as! Bullet).touchedBoundary()
    }
    
    // BULLET & ENEMY
    else if (contact.bodyA.categoryBitMask == CategoryMasks.enemy) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.bullet) {
      (contact.bodyA.node as! Enemy).touchedBullet(bullet: (contact.bodyB.node as! Bullet))
    }
    else if (contact.bodyA.categoryBitMask == CategoryMasks.bullet) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.enemy) {
      (contact.bodyB.node as! Enemy).touchedBullet(bullet: (contact.bodyA.node as! Bullet))
    }
      
    // ENEMY & BOUNDARY
    else if (contact.bodyA.categoryBitMask == CategoryMasks.boundary) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.enemy) {
      
      let enemy = contact.bodyB.node as! Enemy
      if enemy.position.x < 0 {
        enemy.touchedBoundary()
      }
    }
    
    // SALVAGE & COLLECTING PLAYER
    else if (contact.bodyA.categoryBitMask == CategoryMasks.collectingPlayer) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.salvage) {
      collectingPlayer.collidedWithSalvage(contact.bodyB.node as! Salvage)
    }
    
    // SALVAGE DEPOT & COLLECTING PLAYER
    else if (contact.bodyA.categoryBitMask == CategoryMasks.collectingPlayer) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.salvageDepot) {
      collectingPlayer.collidedWithSalvageDepot(depotForName(contact.bodyB.node!.name!)!)
    }
    
    // ENEMY & MAIN BASE
    else if (contact.bodyA.categoryBitMask == CategoryMasks.mainBase) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.enemy) {
      
      mainBase.hitByEnemy()
      contact.bodyB.node?.removeFromParent()
    }
    
    // ENEMY & COLLECTING PLAYER
    else if (contact.bodyA.categoryBitMask == CategoryMasks.collectingPlayer) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.enemy) {
      
      collectingPlayer.hitByEnemy()
      contact.bodyB.node?.removeFromParent()
    }
    
    // ENEMY & SHOOTING PLAYER
    else if (contact.bodyA.categoryBitMask == CategoryMasks.shootingPlayer) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.enemy) {
      
      shootingPlayer.hitByEnemy()
      contact.bodyB.node?.removeFromParent()
    }
    
    // ENEMY & SALVAGE DEPOT
    else if (contact.bodyA.categoryBitMask == CategoryMasks.salvageDepot) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.enemy) {
      
      depotForName(contact.bodyA.node!.name!)!.hitByEnemy()
      contact.bodyB.node?.removeFromParent()
    }
    
    // POWERUP & SHOOTING PLAYER
    else if (contact.bodyA.categoryBitMask == CategoryMasks.shootingPlayer) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.powerup) {

      shootingPlayer.pickedUpPowerup(type: (contact.bodyB.node as! Powerup).type)
      contact.bodyB.node?.removeFromParent()
    }
    
  }
  
  func didEnd(_ contact: SKPhysicsContact) {
    // SALVAGE & COLLECTING PLAYER
    if (contact.bodyA.categoryBitMask == CategoryMasks.collectingPlayer) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.salvage) {
      collectingPlayer.uncollidedWithSalvage(contact.bodyB.node as! Salvage)
    }
    
    // SALVAGE DEPOT & COLLECTING PLAYER
    else if (contact.bodyA.categoryBitMask == CategoryMasks.collectingPlayer) &&
      (contact.bodyB.categoryBitMask == CategoryMasks.salvageDepot) {
      collectingPlayer.uncollidedWithSalvageDepot(depotForName(contact.bodyB.node!.name!)!)
    }
  }
  
  func setScoreLabel() {
    scoreLabel.text = "Score: \(score)"
  }
  
  func gotSalvage(type: SalvageType) {
    switch type {
    case .rubbish: score += 1
    case .good: score += 2
    case .valuable: score += 5
    case .legendary: score += 10
    }
    setScoreLabel()
  }
  
  func killedEnemy() {
    score += 1
    setScoreLabel()
  }
  
  func nuke() {
    for child in children {
      if let enemy = child as? Enemy {
        enemy.health = 0
        enemy.checkIfDead()
      }
    }
  }
  
  func lose() {
    if let scene = SKScene(fileNamed: "MenuScene") {
      // Set the scale mode to scale to fit the window
      scene.scaleMode = .aspectFill
      
      // Present the scene
      view!.presentScene(scene, transition: SKTransition.doorsCloseVertical(withDuration: 1))
    }
  }
  
  func depotForName(_ name: String) -> SalvageDepot? {
    switch name {
    case "rubbishDepot": return rubbishDepot
    case "goodDepot": return goodDepot
    case "valuableDepot": return valuableDepot
    case "legendaryDepot": return legendaryDepot
    default: return nil
    }
  }
  
  func depotForType(_ type: SalvageType) -> SalvageDepot {
    switch type {
    case .rubbish: return rubbishDepot
    case .good: return goodDepot
    case .valuable: return valuableDepot
    case .legendary: return legendaryDepot
    }
  }
}
