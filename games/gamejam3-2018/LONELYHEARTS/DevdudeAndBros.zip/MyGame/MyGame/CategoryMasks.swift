//
//  CategoryMasks
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import Foundation

struct CategoryMasks {
  static let shootingPlayer: UInt32 = 0x1 << 0
  static let collectingPlayer: UInt32 = 0x1 << 1
  static let salvage: UInt32 = 0x1 << 2
  static let salvageDepot: UInt32 = 0x1 << 3
  static let bullet: UInt32 = 0x1 << 4
  static let enemy: UInt32 = 0x1 << 5
  static let boundary: UInt32 = 0x1 << 6
  static let mainBase: UInt32 = 0x1 << 7
  static let powerup: UInt32 = 0x1 << 8
}
