//
//  Salvage.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

enum SalvageType {
  case rubbish
  case good
  case valuable
  case legendary
}

class Salvage: SKSpriteNode {
  
  let type: SalvageType
  
  var timerToFadeActions: Timer?
  var timerToDisappear: Timer?
  
  init(type: SalvageType, position: CGPoint) {
    let texture = SKTexture(imageNamed: Salvage.sprite(forType: type))
    self.type = type
    
    super.init(texture: texture, color: .clear
      , size: CGSize(width: 128, height: 128))
    
    makePhysicsBody()
    
    self.position = position
    
    droppedOff()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func makePhysicsBody() {
    self.physicsBody = SKPhysicsBody(texture: self.texture!, size: self.size)
    self.physicsBody?.allowsRotation = false
    self.physicsBody?.linearDamping = 0
    
    self.physicsBody?.categoryBitMask = CategoryMasks.salvage
    self.physicsBody?.collisionBitMask = 0
  }
  
  private func startDisappearing() {
    let onOffAction = SKAction.sequence([SKAction.fadeOut(withDuration: 0.25), SKAction.fadeIn(withDuration: 0.25)])
    let foreverAction = SKAction.repeatForever(onOffAction)
    
    self.run(foreverAction, withKey: "DisappearingAction")
    
    timerToDisappear = Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false) { timer in
      self.disappear()
    }
  }
  
  private func disappear() {
    self.removeFromParent()
  }
  
  func pickedUp() {
    timerToFadeActions?.invalidate()
    timerToDisappear?.invalidate()
    self.removeAction(forKey: "DisappearingAction")
    self.alpha = 1
  }
  
  func droppedOff() {
    timerToFadeActions = Timer.scheduledTimer(withTimeInterval: 7.5, repeats: false) { timer in
      self.startDisappearing()
    }
  }
  
  private static func sprite(forType type: SalvageType) -> String {
    switch type {
    case .rubbish: return ["boot_rubbish","ea_rubbish","alien_rubbish"][rand(min: 0, max: 2)]
    case .good: return ["cake_good","candy_good","energy_good"][rand(min: 0, max: 2)]
    case .valuable: return ["bottle_valuable","car_valuable","pouch_valuable"][rand(min: 0, max: 2)]
    case .legendary: return ["legendary_katana","waste_legendary","legendary_trophy"][rand(min: 0, max: 2)]
    }
  }
}
