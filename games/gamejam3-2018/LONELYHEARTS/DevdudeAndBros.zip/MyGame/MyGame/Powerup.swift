//
//  Powerup.swift
//  MyGame
//
//  Created by Youssef Moawad on 25/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class Powerup: SKSpriteNode {
  let type: PowerupType
  
  init(type: PowerupType, position: CGPoint) {
    self.type = type
    
    let texture = SKTexture(imageNamed: type.imageName())
    super.init(texture: texture, color: .clear
      , size: CGSize(width: 75, height: 75))
    
    self.physicsBody = SKPhysicsBody(texture: texture, size: self.size)
    self.physicsBody?.allowsRotation = false
    self.physicsBody?.linearDamping = 0
    
    self.physicsBody?.categoryBitMask = CategoryMasks.powerup
    self.physicsBody?.collisionBitMask = 0
    
    self.position = position
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}

enum PowerupType {
  case speed
  case life
  case betterGun
  case splashGun
  
  func imageName() -> String {
    switch self {
    case .speed: return "fast_boots"
    case .life: return "heart"
    case .betterGun: return "rifle"
    case .splashGun: return "bazooka"
    }
  }
}

