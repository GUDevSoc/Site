//
//  SalvageDepot.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class SalvageDepot {
  var node: SKSpriteNode
  var type: SalvageType
  
  var amountOfSalvageCollected: Int = 0
  
  let maxHealth: Int = 12
  var health: Int
  
  let quota: Int
  
  init(type: SalvageType, node: SKSpriteNode) {
    self.node = node
    self.type = type
    health = maxHealth
    
    self.node.physicsBody = SKPhysicsBody(rectangleOf: self.node.frame.size)
    self.node.physicsBody?.restitution = 0
    self.node.physicsBody?.isDynamic = false
    self.node.physicsBody?.categoryBitMask = CategoryMasks.salvageDepot
    self.node.physicsBody?.contactTestBitMask = CategoryMasks.enemy
    
    switch type {
    case .rubbish: quota = 1
    case .good: quota = 3
    case .valuable: quota = 2
    case .legendary: quota = 2
    }
    
    makeHealthBar()
    makeCollectedBar()
  }
  
  func recieveSalvage() {
    amountOfSalvageCollected += 1
    makeCollectedBar()
    
    if amountOfSalvageCollected % quota == 0 {
      makePowerup()
    }
    
    (node.scene as! GameScene).gotSalvage(type: type)
  }
  
  func makePowerup() {
    let powerupType: PowerupType
    
    self.node.run(SKAction.playSoundFileNamed("drop_item.wav", waitForCompletion:false))
    
    switch type {
    case .rubbish: powerupType = [PowerupType.life, PowerupType.speed][rand(min: 0, max: 1)]
    case .good: powerupType = PowerupType.betterGun
    case .valuable: powerupType = PowerupType.splashGun
    case .legendary: return nuke()
    }
    
    let powerup = Powerup(type: powerupType, position: CGPoint(x: self.node.position.x+0.6*self.node.size.width, y: self.node.position.y))
    (self.node.parent as! SKScene).addChild(powerup)
  }
  
  func nuke() {
    (node.parent as! GameScene).nuke()
  }
  
  func hitByEnemy() {
    health -= 1
    
    if health == 0 {
      node.removeFromParent()
    }
    
    makeHealthBar()
  }
  
  func makeHealthBar() {
    if let healthBar = node.childNode(withName: "healthBar") {
      healthBar.removeFromParent()
    }
    
    let boundingRect = SKShapeNode(rect: CGRect(x: -0.4*node.size.width, y: 0.2*node.size.width, width: 0.8*node.size.width, height: 5))
    boundingRect.strokeColor = .magenta
    boundingRect.name = "healthBar"
    boundingRect.zPosition = 10
    
    let healthBar = SKShapeNode(rect: CGRect(x: -0.4*node.size.width, y: 0.2*node.size.width, width: 0.8*node.size.width*CGFloat(health)/CGFloat(maxHealth), height: 5))
    healthBar.lineWidth = 0
    healthBar.fillColor = .green
    healthBar.zPosition = 9
    
    boundingRect.xScale = 1/node.xScale
    boundingRect.yScale = 1/node.yScale
    
    boundingRect.addChild(healthBar)
    
    self.node.addChild(boundingRect)
  }
  
  func makeCollectedBar() {
    if let collectedBar = node.childNode(withName: "collectedBar") {
      collectedBar.removeFromParent()
    }
    
    let boundingRect = SKShapeNode(rect: CGRect(x: -0.4*node.size.width, y: 0.125*node.size.width, width: 0.8*node.size.width, height: 10))
    boundingRect.strokeColor = .blue
    boundingRect.lineWidth = 2
    boundingRect.name = "collectedBar"
    boundingRect.zPosition = 10
    
    let collectedBar = SKShapeNode(rect: CGRect(x: -0.4*node.size.width, y: 0.125*node.size.width, width: 0.8*node.size.width*CGFloat(amountOfSalvageCollected%quota)/CGFloat(quota), height: 10))
    collectedBar.lineWidth = 0
    collectedBar.fillColor = .purple
    collectedBar.zPosition = 9
    
    boundingRect.xScale = 1/node.xScale
    boundingRect.yScale = 1/node.yScale
    
    boundingRect.addChild(collectedBar)
    
    self.node.addChild(boundingRect)
  }
  
  func pickedUpHeart() {
    health += 3
    if health > maxHealth { health = maxHealth }
    makeHealthBar()
  }
}
