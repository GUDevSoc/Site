//
//  Enemy.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class Enemy: SKSpriteNode {
  static let bulletSpeed: CGFloat = 600
  
  var health: Int
  var maxHealth: Int
  
  var minimumSpeed = 100
  var maximumSpeed = 150
  
  init(type: EnemyType, spawnLocation: CGPoint, targetLocation: CGPoint) {
    self.maxHealth = rand(min: 1, max: 3)
    health = maxHealth
    
    let textureNames = ["coolguy_1", "demon_1", "demon_black_1", "demon_blue_1", "demon_red_1"]
    let picked = textureNames[rand(min: 0, max: textureNames.count-1)]
    
    let texture = SKTexture(imageNamed: picked)
    super.init(texture: texture, color: .clear
      , size: texture.size())
    
    self.setScale(0.5)
    
    if(picked == "coolguy_1") {
      self.xScale *= -1
    }
    
    self.physicsBody = SKPhysicsBody(texture: texture, size: texture.size())
    self.physicsBody?.allowsRotation = false
    self.physicsBody?.linearDamping = 0
    
    self.physicsBody?.categoryBitMask = CategoryMasks.enemy
    self.physicsBody?.contactTestBitMask = CategoryMasks.bullet | CategoryMasks.boundary
    self.physicsBody?.collisionBitMask = 0

    self.position = spawnLocation
    
    let angle = atan2((targetLocation.y - spawnLocation.y), (targetLocation.x - spawnLocation.x))
    let speed = CGFloat(rand(min: minimumSpeed, max: maximumSpeed))
    self.physicsBody?.velocity = CGVector(dx: speed*cos(angle), dy: speed*sin(angle))
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func touchedBoundary() {
    self.removeFromParent()
  }
  
  func touchedBullet(bullet: Bullet) {
    switch bullet.type {
    case .base:
      health -= 1
    case .better:
      health -= 2
    case .splash:
      health -= 2
      let nearbyNodes = self.nodesInVicinity(point: self.position, tolerance: 100)
      for node in nearbyNodes {
        if let enemy = node as? Enemy {
          enemy.health -= 2
          enemy.checkIfDead()
        }
      }
    }
    
    self.run(SKAction.playSoundFileNamed("enemy_death.wav", waitForCompletion:false))
    
    checkIfDead()
    
    bullet.removeFromParent()
  }
  
  func checkIfDead() {
    if health == 0 {
      
      (self.scene as! GameScene).killedEnemy()
      
      var salvageType: SalvageType = .rubbish
      let random = rand(min: 0, max: 100)
      if random <= 50 { salvageType = .rubbish }
      else if random > 50 && random <= 80 { salvageType = .good }
      else if random > 80 && random <= 95 { salvageType = .valuable }
      else if random > 95 { salvageType = .legendary }
      
      
      if rand(min: 0, max: 3) < 3 {
        let salvage = Salvage(type: salvageType, position: self.position)
        (self.parent as! SKScene).addChild(salvage)
      }
      
      self.removeFromParent()
    }
  }
  
  func makeHealthBar() {
    if let healthBar = self.childNode(withName: "healthBar") {
      healthBar.removeFromParent()
    }
    
    let boundingRect = SKShapeNode(rect: CGRect(x: -0.3*self.size.width, y: 0.3*self.size.width, width: 0.6*self.size.width, height: 5))
    boundingRect.strokeColor = .magenta
    boundingRect.name = "healthBar"
    boundingRect.zPosition = 10
    
    let healthBar = SKShapeNode(rect: CGRect(x: -0.3*self.size.width, y: 0.3*self.size.width, width: 0.6*self.size.width*CGFloat(health)/CGFloat(maxHealth), height: 5))
    healthBar.lineWidth = 0
    healthBar.fillColor = .green
    healthBar.zPosition = 9
    
    boundingRect.addChild(healthBar)
    boundingRect.xScale = self.xScale
    
    self.addChild(boundingRect)
  }
}

enum EnemyType {
  case base
}
