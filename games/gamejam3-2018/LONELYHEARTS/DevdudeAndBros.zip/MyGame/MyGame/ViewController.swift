//
//  ViewController.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import Cocoa
import SpriteKit
import GameplayKit

class ViewController: NSViewController {
  
  @IBOutlet var skView: SKView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    if let view = self.skView {
      if let scene = SKScene(fileNamed: "MenuScene") {
        // Set the scale mode to scale to fit the window
        scene.scaleMode = .aspectFill
        
        // Present the scene
        view.presentScene(scene)
      }
      
      view.ignoresSiblingOrder = true
      
      view.showsFPS = true
      view.showsNodeCount = true
//      view.showsPhysics = true
      
      let options = [NSTrackingArea.Options.mouseMoved, NSTrackingArea.Options.activeInKeyWindow, NSTrackingArea.Options.activeAlways, NSTrackingArea.Options.inVisibleRect, ] as NSTrackingArea.Options
      let tracker = NSTrackingArea(rect: view.frame, options: options, owner: self.view, userInfo: nil)
      view.addTrackingArea(tracker)
    }
  }
}

func rand(min: Int, max:Int) -> Int {
  return min + Int(arc4random_uniform(UInt32(max - min + 1)))
}
