//
//  Player.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class Player {
  var node: SKSpriteNode
  var speed: CGFloat = 4
  var maxVelocity: CGFloat = 450
  
  var movingUp: Bool = false
  var movingDown: Bool = false
  var movingLeft: Bool = false
  var movingRight: Bool = false
  
  var lookingAngle: CGFloat = 0
  
  init(withNode node: SKSpriteNode) {
    self.node = node
    
//    self.node.physicsBody = SKPhysicsBody(texture: node.texture!, size: node.size)
    self.node.physicsBody = SKPhysicsBody(rectangleOf: node.size)
    self.node.physicsBody?.allowsRotation = false
    self.node.physicsBody?.collisionBitMask = CategoryMasks.boundary | CategoryMasks.salvageDepot
    self.node.physicsBody?.linearDamping = 0.9999
  }
  
  func update(_ currentTime: TimeInterval) {
    if movingUp { moveUp() }
    else if movingDown { moveDown() }
    if movingLeft { moveLeft() }
    else if movingRight { moveRight() }
  }
  
  func startMoving(inDirection direction: Direction) {
    switch direction {
    case .up:
      movingUp = true
      movingDown = false
    case .down:
      movingDown = true
      movingUp = false
    case .left:
      movingLeft = true
      movingRight = false
      self.node.xScale = 1
      for node in node.children {
        node.xScale = 1
      }
    case .right:
      movingRight = true
      movingLeft = false
      self.node.xScale = -1
      for node in node.children {
        node.xScale = -1
      }
    }
  }
  
  func stopMoving(inDirection direction: Direction) {
    switch direction {
    case .up:
      movingUp = false
    case .down:
      movingDown = false
    case .left:
      movingLeft = false
    case .right:
      movingRight = false
    }
  }
  
  private func moveUp() {
    if isUnderMaxVelocity() { node.physicsBody?.applyImpulse(CGVector(dx: 0, dy: speed)) }
  }
  
  private func moveDown() {
    if isUnderMaxVelocity() { node.physicsBody?.applyImpulse(CGVector(dx: 0, dy: -speed)) }
  }
  
  private func moveLeft() {
    if isUnderMaxVelocity() { node.physicsBody?.applyImpulse(CGVector(dx: -speed, dy: 0)) }
  }
  
  private func moveRight() {
    if isUnderMaxVelocity() { node.physicsBody?.applyImpulse(CGVector(dx: speed, dy: 0)) }
  }
  
  private func isUnderMaxVelocity() -> Bool {
    let dx = (self.node.physicsBody?.velocity.dx)!
    let dy = (self.node.physicsBody?.velocity.dy)!
    
    let currentVelocity: CGFloat = sqrt(pow(dx, 2) + pow(dy, 2))
    
    return currentVelocity < maxVelocity
  }
  
  func mouseMoved(toPosition pos: CGPoint) {
    lookingAngle = atan2((pos.y - self.position.y), (pos.x - self.position.x))
  }
  
  var position: CGPoint {
    get { return self.node.position }
    set { self.node.position = newValue }
  }
}

enum Direction {
  case up
  case down
  case left
  case right
}

