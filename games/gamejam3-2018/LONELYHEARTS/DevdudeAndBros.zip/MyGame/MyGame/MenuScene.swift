//
//  MenuScene.swift
//  MyGame
//
//  Created by Youssef Moawad on 25/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class MenuScene: SKScene {
  
  func touchDown(atPoint pos : CGPoint) {
    play()
  }
  
  func touchMoved(toPoint pos : CGPoint) {
    
  }
  
  func touchUp(atPoint pos : CGPoint) {
    
  }
  
  override func mouseDown(with event: NSEvent) {
    self.touchDown(atPoint: event.location(in: self))
  }
  
  override func mouseDragged(with event: NSEvent) {
    self.touchMoved(toPoint: event.location(in: self))
  }
  
  override func mouseUp(with event: NSEvent) {
    self.touchUp(atPoint: event.location(in: self))
  }
  
  
  func play() {
    // Load the SKScene from 'GameScene.sks'
    if let scene = SKScene(fileNamed: "GameScene") {
      // Set the scale mode to scale to fit the window
      scene.scaleMode = .aspectFill
      
      // Present the scene
      view!.presentScene(scene, transition: SKTransition.doorsOpenVertical(withDuration: 1))
    }
  }
  
}
