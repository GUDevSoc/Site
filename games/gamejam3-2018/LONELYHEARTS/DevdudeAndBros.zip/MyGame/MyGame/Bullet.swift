//
//  Bullet.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class Bullet: SKSpriteNode {
  static let bulletSpeed: CGFloat = 600
  
  let type: BulletType
  
  init(type: BulletType, angle: CGFloat, position: CGPoint) {
    self.type = type
    
    let texture = SKTexture(imageNamed: type.spriteName())
    super.init(texture: texture, color: .clear
      , size: texture.size())
    
    self.setScale(0.2)
    
    self.physicsBody = SKPhysicsBody(rectangleOf: self.frame.size)
    self.physicsBody?.allowsRotation = false
    self.physicsBody?.linearDamping = 0
    
    self.physicsBody?.categoryBitMask = CategoryMasks.bullet
    self.physicsBody?.contactTestBitMask = CategoryMasks.boundary
    self.physicsBody?.collisionBitMask = CategoryMasks.boundary

    self.physicsBody?.velocity = CGVector(dx: Bullet.bulletSpeed*cos(angle), dy: Bullet.bulletSpeed*sin(angle))
    self.zRotation = angle
    self.position = CGPoint(x: position.x+50*cos(angle), y: position.y+50*sin(angle))
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func touchedBoundary() {
    self.removeFromParent()
  }
}

enum BulletType {
  case base
  case better
  case splash
  
  func spriteName() -> String {
    switch self {
      case .base: return "bullet"
      case .better: return "betterbullet"
      case .splash: return "bazook"
    }
  }
}
