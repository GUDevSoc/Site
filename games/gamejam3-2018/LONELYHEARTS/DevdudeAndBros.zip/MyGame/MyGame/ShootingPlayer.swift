//
//  ShootingPlayer.swift
//  MyGame
//
//  Created by Youssef Moawad on 24/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class ShootingPlayer: Player {
  
  let maxCooldown: Int = 15
  var cooldown: Int
  
  var onHalt: Bool = false
  let onHaltFrames: Int = 80
  var onHaltFramesLeft: Int = 0
  
  let framesToIncreaseCooldown: Int = 12
  var framesToIncreaseCooldownLeft: Int
  
  let shotRecentlyFrames: Int = 12
  var shotRecentlyLeft: Int = 0
  
  var hasSpeed: Bool = false
  var hasBetterGun: Bool = false
  var hasSplashGun: Bool = false
  
  var speedTimer: Timer?
  var betterGunTimer: Timer?
  var splashGunTimer: Timer?
  
  override init(withNode node: SKSpriteNode) {
    cooldown = maxCooldown
    framesToIncreaseCooldownLeft = framesToIncreaseCooldown
    
    super.init(withNode: node)
    
    self.node.physicsBody?.categoryBitMask = CategoryMasks.shootingPlayer
    self.node.physicsBody?.collisionBitMask &= ~CategoryMasks.collectingPlayer
    self.node.physicsBody?.collisionBitMask |= CategoryMasks.salvageDepot
    self.node.physicsBody?.collisionBitMask |= CategoryMasks.mainBase
    self.node.physicsBody?.contactTestBitMask = CategoryMasks.enemy | CategoryMasks.powerup
    
    self.node.color = .red
  }
  
  override func update(_ currentTime: TimeInterval) {
    super.update(currentTime)
    
    if (lookingAngle > .pi/2 && lookingAngle < .pi) || (lookingAngle < -.pi/2 && lookingAngle > -.pi) {
      node.xScale = 1
      node.zRotation = lookingAngle + .pi
    } else {
      node.xScale = -1
      node.zRotation = lookingAngle
    }
    
    if onHaltFramesLeft > 0 {
      onHaltFramesLeft -= 1
    } else {
      node.colorBlendFactor = 0
      if shotRecentlyLeft > 0 { shotRecentlyLeft -= 1 }
      
      if shotRecentlyLeft == 0 {
        if cooldown < maxCooldown {
          if framesToIncreaseCooldownLeft == 0 {
            cooldown += 1
            if cooldown != maxCooldown { makeCooldownBar() }
            else { removeCooldownBar() }
            framesToIncreaseCooldownLeft = framesToIncreaseCooldown
          } else {
            framesToIncreaseCooldownLeft -= 1
          }
        }
      }
    }
  }
  
  func shoot() {
    if cooldown > 0 && onHaltFramesLeft == 0 {
      let bullet = Bullet(type: appropriateBulletType(), angle: lookingAngle, position: self.position)
      (node.parent as! SKScene).addChild(bullet)
      
      self.node.run(SKAction.playSoundFileNamed("pew.wav", waitForCompletion:false))
      
      shotRecentlyLeft = shotRecentlyFrames
      cooldown -= 1
      makeCooldownBar()
    } else {
      if onHaltFramesLeft == 0 {
        self.node.run(SKAction.playSoundFileNamed("cooldown.wav", waitForCompletion:false))
        onHaltFramesLeft = onHaltFrames
        cooldown = maxCooldown
        removeCooldownBar()
        node.colorBlendFactor = 1
      }
    }
  }
  
  func hitByEnemy() {
    onHaltFramesLeft = onHaltFrames
    node.colorBlendFactor = 1
    removeCooldownBar()
  }
  
  func pickedUpPowerup(type: PowerupType) {
    self.node.run(SKAction.playSoundFileNamed("recieve_upgrade.wav", waitForCompletion:false))
    
    switch type {
    case .speed: pickedUpSpeed()
    case .life: pickedUpHeart()
    case .betterGun: pickedUpBetterGun()
    case .splashGun: pickedUpSplashGun()
    }
  }
  
  func pickedUpSpeed() {
    hasSpeed = true
    speed += 2
    maxVelocity += 200
    
    speedTimer?.invalidate()
    speedTimer = Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { _ in
      self.speedExpired()
    }
    
    (node.parent as! GameScene).collectingPlayer.pickedUpSpeed()
  }
  
  func speedExpired() {
    hasSpeed = false
    speed -= 2
    maxVelocity -= 200
    
    (node.parent as! GameScene).collectingPlayer.speedExpired()
  }
  
  func pickedUpHeart() {
    let scene = node.parent as! GameScene
    
    scene.collectingPlayer.pickedUpHeart()
    scene.rubbishDepot.pickedUpHeart()
    scene.goodDepot.pickedUpHeart()
    scene.valuableDepot.pickedUpHeart()
    scene.legendaryDepot.pickedUpHeart()
    scene.mainBase.pickedUpHeart()
  }
  
  func pickedUpBetterGun() {
    self.node.texture = SKTexture(imageNamed: PowerupType.betterGun.imageName())
    hasBetterGun = true
    hasSplashGun = false

    betterGunTimer?.invalidate()
    betterGunTimer = Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { _ in
      self.betterGunExpired()
    }
  }
  
  func betterGunExpired() {
    self.node.texture = SKTexture(imageNamed: "pistol")
    hasBetterGun = false
  }
  
  func pickedUpSplashGun() {
    self.node.texture = SKTexture(imageNamed: PowerupType.splashGun.imageName())
    hasSplashGun = true
    hasBetterGun = false
    
    splashGunTimer?.invalidate()
    splashGunTimer = Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { _ in
      self.splashGunExpired()
    }
  }
  
  func splashGunExpired() {
    self.node.texture = SKTexture(imageNamed: "pistol")
    hasSplashGun = false
  }
  
  private func appropriateBulletType() -> BulletType {
    if hasBetterGun { return .better }
    else if hasSplashGun { return .splash }
    return .base
  }

  func makeCooldownBar() {
    removeCooldownBar()
    
    let boundingRect = SKShapeNode(rect: CGRect(x: -0.3*node.size.width, y: 0.3*node.size.width, width: 0.6*node.size.width, height: 5))
    boundingRect.strokeColor = .purple
    boundingRect.name = "cdBar"
    boundingRect.zPosition = 10
    
    let bar = SKShapeNode(rect: CGRect(x: -0.3*node.size.width, y: 0.3*node.size.width, width: 0.6*node.size.width*CGFloat(cooldown)/CGFloat(maxCooldown), height: 5))
    bar.lineWidth = 0
    bar.fillColor = .blue
    bar.zPosition = 9
    
    boundingRect.addChild(bar)
    boundingRect.xScale = node.xScale
    
    self.node.addChild(boundingRect)
  }
  
  func removeCooldownBar() {
    if let bar = node.childNode(withName: "cdBar") {
      bar.removeFromParent()
    }
  }
}
