//
//  MainBase.swift
//  MyGame
//
//  Created by Youssef Moawad on 25/03/2018.
//  Copyright © 2018 Youssef Moawad. All rights reserved.
//

import SpriteKit

class MainBase {
  var node: SKSpriteNode
  
  let maxHealth: Int = 30
  var health: Int
  
  init(node: SKSpriteNode) {
    self.node = node
    health = maxHealth
    
    self.node.physicsBody = SKPhysicsBody(rectangleOf: node.size)
    self.node.physicsBody?.isDynamic = false
    self.node.physicsBody?.categoryBitMask = CategoryMasks.mainBase
    self.node.physicsBody?.contactTestBitMask = CategoryMasks.enemy
    
    makeHealthBar()
  }
  
  func hitByEnemy() {
    health -= 1
    
    if health == 0 {
      (node.parent as! GameScene).lose()
    }
    
    makeHealthBar()
  }
  
  func makeHealthBar() {
    if let healthBar = node.childNode(withName: "healthBar") {
      healthBar.removeFromParent()
    }
    
    let boundingRect = SKShapeNode(rect: CGRect(x: -0.2*node.size.width, y: 0.2*node.size.width, width: 0.4*node.size.width, height: 5))
    boundingRect.strokeColor = .magenta
    boundingRect.name = "healthBar"
    boundingRect.zPosition = 10
    
    let healthBar = SKShapeNode(rect: CGRect(x: -0.2*node.size.width, y: 0.2*node.size.width, width: 0.4*node.size.width*CGFloat(health)/CGFloat(maxHealth), height: 5))
    healthBar.lineWidth = 0
    healthBar.fillColor = .green
    healthBar.zPosition = 9
    
    boundingRect.addChild(healthBar)
    
    self.node.addChild(boundingRect)
  }
  
  func pickedUpHeart() {
    health += 3
    if health > maxHealth { health = maxHealth }
    makeHealthBar()
  }
}
